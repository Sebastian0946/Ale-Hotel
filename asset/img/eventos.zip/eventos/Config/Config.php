<?php
const base_url = "http://localhost/eventos/";
const host = "localhost";
const user = "root";
const pass = "";
const db = "eventos";
const charset = "charset=utf8";
?>